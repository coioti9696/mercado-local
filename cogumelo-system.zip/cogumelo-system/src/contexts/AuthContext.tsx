import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User, UserRole } from '@/types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string, role: UserRole) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demonstration
const mockUsers: Record<string, User> = {
  'admin@mercado.com': {
    id: 'admin-1',
    email: 'admin@mercado.com',
    name: 'Administrador',
    role: 'admin',
  },
  'produtor@fazendaverde.com': {
    id: 'producer-1',
    email: 'produtor@fazendaverde.com',
    name: 'João da Fazenda',
    role: 'producer',
    producerId: '1',
  },
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  const login = async (email: string, password: string, role: UserRole): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // For demo, accept any login and assign role
    const mockUser = mockUsers[email] || {
      id: `user-${Date.now()}`,
      email,
      name: email.split('@')[0],
      role,
      producerId: role === 'producer' ? '1' : undefined,
    };
    
    setUser(mockUser);
    return true;
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
