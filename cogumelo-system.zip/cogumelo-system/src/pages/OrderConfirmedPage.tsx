import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, ArrowLeft } from 'lucide-react';

const OrderConfirmedPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-background-secondary p-4">
      <div className="max-w-md w-full text-center animate-fade-in">
        <div className="w-20 h-20 mx-auto mb-6 bg-success/10 rounded-full flex items-center justify-center">
          <CheckCircle className="w-10 h-10 text-success" />
        </div>
        
        <h1 className="text-2xl font-bold text-foreground mb-2">
          Pedido confirmado!
        </h1>
        
        <p className="text-muted-foreground mb-8">
          Seu pedido foi enviado para o produtor. Em breve você receberá uma confirmação via WhatsApp.
        </p>

        <div className="bg-card rounded-2xl border border-border p-6 mb-6">
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Número do pedido</span>
              <span className="font-medium">#2024-{Math.floor(Math.random() * 10000)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Status</span>
              <span className="text-info font-medium">Aguardando confirmação</span>
            </div>
          </div>
        </div>

        <Button
          variant="outline"
          size="lg"
          onClick={() => navigate('/loja/fazenda-verde')}
          className="w-full"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar à loja
        </Button>
      </div>
    </div>
  );
};

export default OrderConfirmedPage;
