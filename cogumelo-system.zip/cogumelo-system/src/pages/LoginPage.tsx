import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UserRole } from '@/types';
import { cn } from '@/lib/utils';
import { Store, Shield } from 'lucide-react';

const LoginPage = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'producer' | 'admin'>('producer');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const success = await login(email, password, role);
      if (success) {
        if (role === 'admin') {
          navigate('/app/admin/dashboard');
        } else {
          navigate('/app/produtor/dashboard');
        }
      }
    } catch (err) {
      setError('Erro ao fazer login. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background-secondary p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground">
            Mercado Local
          </h1>
          <p className="text-muted-foreground mt-2">
            Acesse seu painel
          </p>
        </div>

        <div className="bg-card rounded-2xl border border-border p-6 shadow-premium animate-fade-in">
          {/* Role Selector */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            <button
              type="button"
              onClick={() => setRole('producer')}
              className={cn(
                'p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all',
                role === 'producer'
                  ? 'border-primary bg-primary/5'
                  : 'border-border hover:border-primary/50'
              )}
            >
              <Store className={cn(
                'w-6 h-6',
                role === 'producer' ? 'text-primary' : 'text-muted-foreground'
              )} />
              <span className={cn(
                'text-sm font-medium',
                role === 'producer' ? 'text-primary' : 'text-muted-foreground'
              )}>
                Produtor
              </span>
            </button>
            <button
              type="button"
              onClick={() => setRole('admin')}
              className={cn(
                'p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all',
                role === 'admin'
                  ? 'border-primary bg-primary/5'
                  : 'border-border hover:border-primary/50'
              )}
            >
              <Shield className={cn(
                'w-6 h-6',
                role === 'admin' ? 'text-primary' : 'text-muted-foreground'
              )} />
              <span className={cn(
                'text-sm font-medium',
                role === 'admin' ? 'text-primary' : 'text-muted-foreground'
              )}>
                Admin
              </span>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {error && (
              <p className="text-sm text-destructive">{error}</p>
            )}

            <Button
              type="submit"
              variant="premium"
              size="lg"
              className="w-full"
              disabled={isLoading}
            >
              {isLoading ? 'Entrando...' : 'Entrar'}
            </Button>
          </form>

          <div className="mt-6 pt-6 border-t border-border">
            <p className="text-xs text-center text-muted-foreground">
              Para demonstração, use qualquer email/senha.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
