import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { StatsCard } from '@/components/StatsCard';
import { mockProducers } from '@/data/mockData';
import { Store, CheckCircle, AlertTriangle, XCircle, CreditCard } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const navigate = useNavigate();

  const activeSubscriptions = mockProducers.filter(p => p.subscriptionStatus === 'ativo').length;
  const pendingSubscriptions = mockProducers.filter(p => p.subscriptionStatus === 'pendente').length;
  const overdueSubscriptions = mockProducers.filter(p => p.subscriptionStatus === 'atrasado').length;
  const totalProducers = mockProducers.length;

  // Simulated monthly revenue from subscriptions
  const monthlyRevenue = mockProducers
    .filter(p => p.subscriptionStatus === 'ativo')
    .reduce((sum, p) => sum + (p.subscriptionPlan === 'Profissional' ? 199 : 99), 0);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ativo': return 'bg-success/10 text-success';
      case 'pendente': return 'bg-warning/10 text-warning';
      case 'atrasado': return 'bg-destructive/10 text-destructive';
      case 'cancelado': return 'bg-muted text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'ativo': return 'Ativo';
      case 'pendente': return 'Pendente';
      case 'atrasado': return 'Atrasado';
      case 'cancelado': return 'Cancelado';
      default: return status;
    }
  };

  return (
    <DashboardLayout type="admin">
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Controle de produtores e mensalidades</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Total de produtores"
            value={totalProducers}
            icon={Store}
          />
          <StatsCard
            title="Assinaturas ativas"
            value={activeSubscriptions}
            icon={CheckCircle}
            trend={{ value: 5, isPositive: true }}
          />
          <StatsCard
            title="Pagamentos pendentes"
            value={pendingSubscriptions}
            icon={AlertTriangle}
          />
          <StatsCard
            title="Receita mensal"
            value={formatPrice(monthlyRevenue)}
            icon={CreditCard}
            trend={{ value: 12, isPositive: true }}
          />
        </div>

        {/* Subscriptions with issues */}
        {overdueSubscriptions > 0 && (
          <div className="bg-destructive/5 border border-destructive/20 rounded-2xl p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center">
                <XCircle className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <p className="font-semibold text-foreground">
                  {overdueSubscriptions} produtor(es) com pagamento atrasado
                </p>
                <p className="text-sm text-muted-foreground">
                  Ação necessária para regularização
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Producers Overview */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">
              Produtores cadastrados
            </h2>
            <button
              onClick={() => navigate('/app/admin/produtores')}
              className="text-sm text-primary hover:underline"
            >
              Ver todos
            </button>
          </div>

          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="text-left px-4 py-3 text-sm font-medium text-muted-foreground">
                      Produtor
                    </th>
                    <th className="text-left px-4 py-3 text-sm font-medium text-muted-foreground hidden sm:table-cell">
                      Plano
                    </th>
                    <th className="text-left px-4 py-3 text-sm font-medium text-muted-foreground hidden md:table-cell">
                      Último pagamento
                    </th>
                    <th className="text-left px-4 py-3 text-sm font-medium text-muted-foreground">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {mockProducers.slice(0, 5).map((producer) => (
                    <tr key={producer.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={producer.logo}
                            alt={producer.name}
                            className="w-10 h-10 rounded-xl object-cover"
                          />
                          <div>
                            <p className="font-medium text-foreground">{producer.name}</p>
                            <p className="text-sm text-muted-foreground">{producer.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-sm text-muted-foreground hidden sm:table-cell">
                        {producer.subscriptionPlan || '-'}
                      </td>
                      <td className="px-4 py-4 text-sm text-muted-foreground hidden md:table-cell">
                        {producer.lastPaymentDate
                          ? format(producer.lastPaymentDate, "dd/MM/yyyy", { locale: ptBR })
                          : '-'}
                      </td>
                      <td className="px-4 py-4">
                        <span
                          className={cn(
                            'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
                            getStatusColor(producer.subscriptionStatus)
                          )}
                        >
                          {getStatusLabel(producer.subscriptionStatus)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default AdminDashboard;