import { useState } from 'react';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { mockProducers } from '@/data/mockData';
import { Producer, SubscriptionStatus } from '@/types';
import {
  Plus,
  Search,
  ExternalLink,
  Trash2,
  CreditCard,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Clock,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';

const subscriptionStatusConfig: Record<SubscriptionStatus, { label: string; icon: React.ElementType; className: string }> = {
  ativo: { label: 'Ativo', icon: CheckCircle, className: 'bg-success/10 text-success' },
  pendente: { label: 'Pendente', icon: Clock, className: 'bg-warning/10 text-warning' },
  atrasado: { label: 'Atrasado', icon: AlertTriangle, className: 'bg-destructive/10 text-destructive' },
  cancelado: { label: 'Cancelado', icon: XCircle, className: 'bg-muted text-muted-foreground' },
};

const AdminProducers = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [producers, setProducers] = useState<Producer[]>(mockProducers);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newProducer, setNewProducer] = useState({
    name: '',
    email: '',
    phone: '',
    location: '',
    slug: '',
    subscriptionPlan: 'Básico',
  });

  const filteredProducers = producers.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDeleteProducer = (producerId: string, producerName: string) => {
    setProducers(prev => prev.filter(p => p.id !== producerId));
    toast.success(`Produtor "${producerName}" excluído com sucesso`);
  };

  const handleSubscriptionStatusChange = (producerId: string, newStatus: SubscriptionStatus) => {
    setProducers(prev =>
      prev.map(p =>
        p.id === producerId
          ? {
              ...p,
              subscriptionStatus: newStatus,
              isActive: newStatus === 'ativo',
              lastPaymentDate: newStatus === 'ativo' ? new Date() : p.lastPaymentDate,
            }
          : p
      )
    );
    toast.success(`Status da assinatura atualizado para "${subscriptionStatusConfig[newStatus].label}"`);
  };

  const handleCreateProducer = () => {
    if (!newProducer.name || !newProducer.email || !newProducer.slug) {
      toast.error('Preencha todos os campos obrigatórios');
      return;
    }

    const producer: Producer = {
      id: String(Date.now()),
      slug: newProducer.slug.toLowerCase().replace(/\s+/g, '-'),
      name: newProducer.name,
      email: newProducer.email,
      phone: newProducer.phone,
      location: newProducer.location,
      logo: 'https://images.unsplash.com/photo-1560493676-04071c5f467b?w=200&h=200&fit=crop',
      isActive: true,
      createdAt: new Date(),
      subscriptionStatus: 'pendente',
      subscriptionPlan: newProducer.subscriptionPlan,
      subscriptionStartDate: new Date(),
      subscriptionEndDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    };

    setProducers(prev => [producer, ...prev]);
    setNewProducer({ name: '', email: '', phone: '', location: '', slug: '', subscriptionPlan: 'Básico' });
    setIsCreateDialogOpen(false);
    toast.success(`Produtor "${producer.name}" cadastrado com sucesso`);
  };

  const formatPrice = (plan: string) => {
    return plan === 'Profissional' ? 'R$ 199/mês' : 'R$ 99/mês';
  };

  return (
    <DashboardLayout type="admin">
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Produtores</h1>
            <p className="text-muted-foreground">Gerencie produtores e mensalidades</p>
          </div>

          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="premium">
                <Plus className="w-4 h-4 mr-2" />
                Novo produtor
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Cadastrar novo produtor</DialogTitle>
                <DialogDescription>
                  Preencha os dados para cadastrar um novo produtor na plataforma.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome *</Label>
                  <Input
                    id="name"
                    placeholder="Nome do produtor"
                    value={newProducer.name}
                    onChange={(e) => setNewProducer(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="email@produtor.com"
                    value={newProducer.email}
                    onChange={(e) => setNewProducer(prev => ({ ...prev, email: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefone</Label>
                  <Input
                    id="phone"
                    placeholder="(00) 00000-0000"
                    value={newProducer.phone}
                    onChange={(e) => setNewProducer(prev => ({ ...prev, phone: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Localização</Label>
                  <Input
                    id="location"
                    placeholder="Cidade, Estado"
                    value={newProducer.location}
                    onChange={(e) => setNewProducer(prev => ({ ...prev, location: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="slug">Slug da loja *</Label>
                  <Input
                    id="slug"
                    placeholder="nome-da-loja"
                    value={newProducer.slug}
                    onChange={(e) => setNewProducer(prev => ({ ...prev, slug: e.target.value }))}
                  />
                  <p className="text-xs text-muted-foreground">
                    URL da loja: /loja/{newProducer.slug || 'nome-da-loja'}
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="plan">Plano</Label>
                  <Select
                    value={newProducer.subscriptionPlan}
                    onValueChange={(value) => setNewProducer(prev => ({ ...prev, subscriptionPlan: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Básico">Básico - R$ 99/mês</SelectItem>
                      <SelectItem value="Profissional">Profissional - R$ 199/mês</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button variant="premium" onClick={handleCreateProducer}>
                  Cadastrar
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar produtores..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Producers List */}
        <div className="space-y-4">
          {filteredProducers.map((producer) => {
            const statusConfig = subscriptionStatusConfig[producer.subscriptionStatus];
            const StatusIcon = statusConfig.icon;

            return (
              <div
                key={producer.id}
                className="bg-card rounded-2xl border border-border p-4 space-y-4"
              >
                {/* Header */}
                <div className="flex items-start gap-4">
                  <img
                    src={producer.logo}
                    alt={producer.name}
                    className="w-14 h-14 rounded-xl object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-foreground">{producer.name}</h3>
                      <span
                        className={cn(
                          'inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium',
                          statusConfig.className
                        )}
                      >
                        <StatusIcon className="w-3 h-3" />
                        {statusConfig.label}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{producer.email}</p>
                    <p className="text-sm text-muted-foreground">{producer.location}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => window.open(`/loja/${producer.slug}`, '_blank')}
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </div>

                {/* Subscription Info */}
                <div className="bg-muted/50 rounded-xl p-3 space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <CreditCard className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">{producer.subscriptionPlan}</span>
                    <span className="text-muted-foreground">
                      • {formatPrice(producer.subscriptionPlan || 'Básico')}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                    <span>
                      Cadastro: {format(producer.createdAt, "dd/MM/yyyy", { locale: ptBR })}
                    </span>
                    {producer.lastPaymentDate && (
                      <span>
                        Último pagamento: {format(producer.lastPaymentDate, "dd/MM/yyyy", { locale: ptBR })}
                      </span>
                    )}
                    {producer.subscriptionEndDate && (
                      <span>
                        Vencimento: {format(producer.subscriptionEndDate, "dd/MM/yyyy", { locale: ptBR })}
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-border">
                  <p className="text-xs text-muted-foreground mr-auto">Alterar status:</p>
                  
                  <Select
                    value={producer.subscriptionStatus}
                    onValueChange={(value: SubscriptionStatus) =>
                      handleSubscriptionStatusChange(producer.id, value)
                    }
                  >
                    <SelectTrigger className="w-[140px] h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ativo">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-3 h-3 text-success" />
                          Ativo
                        </div>
                      </SelectItem>
                      <SelectItem value="pendente">
                        <div className="flex items-center gap-2">
                          <Clock className="w-3 h-3 text-warning" />
                          Pendente
                        </div>
                      </SelectItem>
                      <SelectItem value="atrasado">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="w-3 h-3 text-destructive" />
                          Atrasado
                        </div>
                      </SelectItem>
                      <SelectItem value="cancelado">
                        <div className="flex items-center gap-2">
                          <XCircle className="w-3 h-3 text-muted-foreground" />
                          Cancelado
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm" className="gap-1.5">
                        <Trash2 className="w-3.5 h-3.5" />
                        Excluir
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Excluir produtor</AlertDialogTitle>
                        <AlertDialogDescription>
                          Tem certeza que deseja excluir "{producer.name}"? Esta ação não pode ser desfeita.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDeleteProducer(producer.id, producer.name)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Excluir
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            );
          })}
        </div>

        {filteredProducers.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Nenhum produtor encontrado.</p>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default AdminProducers;