import { useState } from 'react';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { mockOrders } from '@/data/mockData';
import { Order, OrderStatus } from '@/types';
import { cn } from '@/lib/utils';
import { StatusBadge } from '@/components/StatusBadge';
import { Button } from '@/components/ui/button';
import { Phone, MapPin, Clock, CheckCircle, ChefHat, Truck, XCircle, Package } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { toast } from 'sonner';

const statusTabs: { value: OrderStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'Todos' },
  { value: 'novo', label: 'Novos' },
  { value: 'confirmado', label: 'Confirmados' },
  { value: 'preparo', label: 'Em preparo' },
  { value: 'a_caminho', label: 'A caminho' },
  { value: 'finalizado', label: 'Finalizados' },
  { value: 'cancelado', label: 'Cancelados' },
];

const statusActions: { status: OrderStatus; label: string; icon: React.ElementType; variant: 'default' | 'secondary' | 'outline' | 'destructive' }[] = [
  { status: 'confirmado', label: 'Confirmar', icon: CheckCircle, variant: 'default' },
  { status: 'preparo', label: 'Em Preparo', icon: ChefHat, variant: 'secondary' },
  { status: 'a_caminho', label: 'A Caminho', icon: Truck, variant: 'outline' },
  { status: 'finalizado', label: 'Finalizar', icon: Package, variant: 'default' },
  { status: 'cancelado', label: 'Cancelar', icon: XCircle, variant: 'destructive' },
];

const ProducerOrders = () => {
  const [selectedStatus, setSelectedStatus] = useState<OrderStatus | 'all'>('all');
  const [orders, setOrders] = useState<Order[]>(mockOrders);

  const filteredOrders = selectedStatus === 'all'
    ? orders
    : orders.filter(o => o.status === selectedStatus);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price);
  };

  const paymentLabels = {
    pix: 'PIX',
    dinheiro: 'Dinheiro',
    cartao: 'Cartão',
  };

  const handleStatusChange = (orderId: string, newStatus: OrderStatus) => {
    setOrders(prev =>
      prev.map(order =>
        order.id === orderId
          ? { ...order, status: newStatus, updatedAt: new Date() }
          : order
      )
    );

    const statusLabels: Record<OrderStatus, string> = {
      novo: 'Novo',
      confirmado: 'Confirmado',
      preparo: 'Em preparo',
      a_caminho: 'A caminho',
      finalizado: 'Finalizado',
      cancelado: 'Cancelado',
    };

    toast.success(`Pedido #${orderId} atualizado para "${statusLabels[newStatus]}"`);
  };

  return (
    <DashboardLayout type="producer">
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Pedidos</h1>
          <p className="text-muted-foreground">Gerencie seus pedidos</p>
        </div>

        {/* Status Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 lg:mx-0 lg:px-0">
          {statusTabs.map((tab) => (
            <button
              key={tab.value}
              onClick={() => setSelectedStatus(tab.value)}
              className={cn(
                'px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all',
                selectedStatus === tab.value
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-card border border-border text-muted-foreground hover:bg-accent'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Orders List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredOrders.map((order) => (
            <div
              key={order.id}
              className="bg-card rounded-2xl p-4 shadow-premium border border-border/50 animate-fade-in"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-foreground">#{order.id}</span>
                    <StatusBadge status={order.status} />
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {order.customerName}
                  </p>
                </div>
                <span className="text-lg font-bold text-primary">
                  {formatPrice(order.total)}
                </span>
              </div>

              {/* Contact Info */}
              <div className="space-y-2 mb-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="w-4 h-4" />
                  {order.customerPhone}
                </div>
                {order.customerAddress && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    <span className="line-clamp-1">{order.customerAddress}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  {formatDistanceToNow(order.createdAt, { addSuffix: true, locale: ptBR })}
                </div>
              </div>

              {/* Items Preview */}
              <div className="border-t border-border pt-3 mb-3">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-muted-foreground">
                    {order.items.length} {order.items.length === 1 ? 'item' : 'itens'}
                  </span>
                  <span className="text-muted-foreground">
                    {paymentLabels[order.paymentMethod]}
                  </span>
                </div>
                <div className="space-y-1 text-sm">
                  {order.items.slice(0, 2).map((item) => (
                    <div key={item.productId} className="flex justify-between text-muted-foreground">
                      <span>{item.quantity}x {item.productName}</span>
                      <span>{formatPrice(item.subtotal)}</span>
                    </div>
                  ))}
                  {order.items.length > 2 && (
                    <p className="text-xs text-muted-foreground">
                      +{order.items.length - 2} mais itens
                    </p>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="border-t border-border pt-3">
                <p className="text-xs text-muted-foreground mb-2">Alterar status:</p>
                <div className="flex flex-wrap gap-2">
                  {statusActions.map((action) => {
                    const Icon = action.icon;
                    const isCurrentStatus = order.status === action.status;
                    
                    return (
                      <Button
                        key={action.status}
                        variant={action.variant}
                        size="sm"
                        disabled={isCurrentStatus}
                        onClick={() => handleStatusChange(order.id, action.status)}
                        className={cn(
                          'gap-1.5 text-xs',
                          isCurrentStatus && 'opacity-50 cursor-not-allowed'
                        )}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        {action.label}
                      </Button>
                    );
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredOrders.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Nenhum pedido encontrado.</p>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default ProducerOrders;
