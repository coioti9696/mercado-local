import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { StatsCard } from '@/components/StatsCard';
import { OrderCard } from '@/components/OrderCard';
import { mockOrders } from '@/data/mockData';
import { ShoppingCart, Clock, DollarSign, TrendingUp } from 'lucide-react';

const ProducerDashboard = () => {
  const todayOrders = mockOrders.filter(o => {
    const today = new Date();
    const orderDate = new Date(o.createdAt);
    return orderDate.toDateString() === today.toDateString();
  });

  const pendingOrders = mockOrders.filter(o => 
    o.status === 'novo' || o.status === 'confirmado' || o.status === 'preparo'
  );

  const totalRevenue = mockOrders.reduce((sum, o) => sum + o.total, 0);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price);
  };

  return (
    <DashboardLayout type="producer">
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Visão geral do seu negócio</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard
            title="Pedidos hoje"
            value={todayOrders.length}
            icon={ShoppingCart}
            trend={{ value: 12, isPositive: true }}
          />
          <StatsCard
            title="Pedidos pendentes"
            value={pendingOrders.length}
            icon={Clock}
          />
          <StatsCard
            title="Faturamento total"
            value={formatPrice(totalRevenue)}
            icon={DollarSign}
            trend={{ value: 8, isPositive: true }}
          />
          <StatsCard
            title="Ticket médio"
            value={formatPrice(totalRevenue / mockOrders.length)}
            icon={TrendingUp}
          />
        </div>

        {/* Recent Orders */}
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4">
            Últimos pedidos
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockOrders.slice(0, 4).map((order) => (
              <OrderCard key={order.id} order={order} />
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default ProducerDashboard;
