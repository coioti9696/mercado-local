import { useState } from 'react';
import { DashboardLayout } from '@/components/layouts/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Upload, Save } from 'lucide-react';

const ProducerSettings = () => {
  const [formData, setFormData] = useState({
    name: 'Fazenda Verde Orgânicos',
    location: 'Campinas, SP',
    acceptPix: true,
    acceptCash: true,
    acceptCard: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Save settings
  };

  return (
    <DashboardLayout type="producer">
      <div className="space-y-6 max-w-2xl">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Configurações</h1>
          <p className="text-muted-foreground">Personalize sua loja</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Logo & Cover */}
          <div className="bg-card rounded-2xl border border-border p-6 space-y-6">
            <h2 className="font-semibold text-foreground">Imagens</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-3">
                <Label>Logo</Label>
                <div className="aspect-square w-32 rounded-2xl border-2 border-dashed border-border bg-muted flex items-center justify-center cursor-pointer hover:border-primary transition-colors">
                  <Upload className="w-6 h-6 text-muted-foreground" />
                </div>
              </div>
              <div className="space-y-3">
                <Label>Imagem de capa</Label>
                <div className="aspect-video rounded-2xl border-2 border-dashed border-border bg-muted flex items-center justify-center cursor-pointer hover:border-primary transition-colors">
                  <Upload className="w-6 h-6 text-muted-foreground" />
                </div>
              </div>
            </div>
          </div>

          {/* Basic Info */}
          <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
            <h2 className="font-semibold text-foreground">Informações</h2>
            
            <div className="space-y-2">
              <Label htmlFor="name">Nome da loja</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Localização</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              />
            </div>
          </div>

          {/* Payment Methods */}
          <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
            <h2 className="font-semibold text-foreground">Formas de pagamento</h2>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="pix">PIX</Label>
                <Switch
                  id="pix"
                  checked={formData.acceptPix}
                  onCheckedChange={(checked) => setFormData({ ...formData, acceptPix: checked })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="cash">Dinheiro</Label>
                <Switch
                  id="cash"
                  checked={formData.acceptCash}
                  onCheckedChange={(checked) => setFormData({ ...formData, acceptCash: checked })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="card">Cartão</Label>
                <Switch
                  id="card"
                  checked={formData.acceptCard}
                  onCheckedChange={(checked) => setFormData({ ...formData, acceptCard: checked })}
                />
              </div>
            </div>
          </div>

          <Button type="submit" variant="premium" size="lg">
            <Save className="w-4 h-4 mr-2" />
            Salvar alterações
          </Button>
        </form>
      </div>
    </DashboardLayout>
  );
};

export default ProducerSettings;
