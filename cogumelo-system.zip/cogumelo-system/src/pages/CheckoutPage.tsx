import { useState } from 'react';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Minus, Plus, Trash2, CreditCard, Banknote, Smartphone } from 'lucide-react';
import { PaymentMethod } from '@/types';
import { cn } from '@/lib/utils';

const CheckoutPage = () => {
  const navigate = useNavigate();
  const { items, total, updateQuantity, removeItem, clearCart } = useCart();
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('pix');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    notes: '',
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would send the order to the backend
    clearCart();
    navigate('/pedido-confirmado');
  };

  const paymentOptions = [
    { value: 'pix' as PaymentMethod, label: 'PIX', icon: Smartphone },
    { value: 'dinheiro' as PaymentMethod, label: 'Dinheiro', icon: Banknote },
    { value: 'cartao' as PaymentMethod, label: 'Cartão', icon: CreditCard },
  ];

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background-secondary p-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Carrinho vazio
          </h1>
          <p className="text-muted-foreground mb-4">
            Adicione produtos para continuar.
          </p>
          <Button onClick={() => navigate(-1)}>Voltar à loja</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background-secondary">
      {/* Header */}
      <header className="sticky top-0 bg-background border-b border-border z-10">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">Finalizar pedido</h1>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6 pb-32">
        {/* Cart Items */}
        <section className="mb-6">
          <h2 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">
            Seu pedido
          </h2>
          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            {items.map((item, index) => (
              <div
                key={item.product.id}
                className={cn(
                  'p-4 flex items-center gap-4',
                  index !== items.length - 1 && 'border-b border-border'
                )}
              >
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="w-16 h-16 rounded-xl object-cover"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-foreground truncate">
                    {item.product.name}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {formatPrice(item.product.price)}/{item.product.unit}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                    className="p-1.5 hover:bg-muted rounded-lg transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-8 text-center font-medium">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                    className="p-1.5 hover:bg-muted rounded-lg transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => removeItem(item.product.id)}
                    className="p-1.5 hover:bg-destructive/10 text-destructive rounded-lg transition-colors ml-2"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Customer Form */}
        <form onSubmit={handleSubmit}>
          <section className="mb-6">
            <h2 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">
              Seus dados
            </h2>
            <div className="bg-card rounded-2xl border border-border p-4 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome completo</Label>
                <Input
                  id="name"
                  placeholder="Seu nome"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">WhatsApp</Label>
                <Input
                  id="phone"
                  placeholder="(00) 00000-0000"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Endereço de entrega (opcional)</Label>
                <Input
                  id="address"
                  placeholder="Rua, número, bairro"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">Observações (opcional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Alguma observação para o produtor?"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                />
              </div>
            </div>
          </section>

          {/* Payment Method */}
          <section className="mb-6">
            <h2 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">
              Forma de pagamento
            </h2>
            <div className="grid grid-cols-3 gap-3">
              {paymentOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setPaymentMethod(option.value)}
                  className={cn(
                    'p-4 rounded-xl border-2 flex flex-col items-center gap-2 transition-all',
                    paymentMethod === option.value
                      ? 'border-primary bg-primary/5'
                      : 'border-border bg-card hover:border-primary/50'
                  )}
                >
                  <option.icon className={cn(
                    'w-6 h-6',
                    paymentMethod === option.value ? 'text-primary' : 'text-muted-foreground'
                  )} />
                  <span className={cn(
                    'text-sm font-medium',
                    paymentMethod === option.value ? 'text-primary' : 'text-muted-foreground'
                  )}>
                    {option.label}
                  </span>
                </button>
              ))}
            </div>
          </section>
        </form>
      </main>

      {/* Fixed Footer */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background border-t border-border shadow-lg">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-3">
            <span className="text-muted-foreground">Total</span>
            <span className="text-2xl font-bold text-primary">{formatPrice(total)}</span>
          </div>
          <Button
            variant="premium"
            size="xl"
            className="w-full"
            onClick={handleSubmit}
          >
            Confirmar pedido
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
