import { useParams, useNavigate } from 'react-router-dom';
import { getProducerBySlug, getProductsByProducer, mockOrders } from '@/data/mockData';
import { ProductCard } from '@/components/ProductCard';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { ShoppingBag, MapPin, History } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { StatusBadge } from '@/components/StatusBadge';

const StorePage = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { itemCount, total } = useCart();

  const producer = getProducerBySlug(slug || '');
  const products = producer ? getProductsByProducer(producer.id) : [];

  // Filtrar pedidos de hoje para este produtor
  const today = new Date();
  const todayOrders = mockOrders.filter((order) => {
    const orderDate = new Date(order.createdAt);
    return (
      order.producerId === producer?.id &&
      orderDate.getDate() === today.getDate() &&
      orderDate.getMonth() === today.getMonth() &&
      orderDate.getFullYear() === today.getFullYear()
    );
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(price);
  };

  if (!producer) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background-secondary">
        <div className="text-center p-8">
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Produtor não encontrado
          </h1>
          <p className="text-muted-foreground">
            Verifique o endereço e tente novamente.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background-secondary">
      {/* Header do Produtor */}
      <header className="relative">
        {/* Cover Image */}
        <div className="h-40 md:h-56 w-full overflow-hidden">
          <img
            src={producer.coverImage || 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1200&h=400&fit=crop'}
            alt="Capa"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
        </div>

        {/* Producer Info */}
        <div className="relative -mt-16 px-4 pb-6">
          <div className="max-w-2xl mx-auto">
            <div className="flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-2xl overflow-hidden border-4 border-background shadow-premium-lg bg-card">
                <img
                  src={producer.logo || 'https://images.unsplash.com/photo-1560493676-04071c5f467b?w=200&h=200&fit=crop'}
                  alt={producer.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <h1 className="text-2xl font-bold text-foreground mt-4">
                {producer.name}
              </h1>
              <div className="flex items-center gap-1.5 text-muted-foreground mt-2">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">{producer.location}</span>
              </div>

              {/* Botão Histórico de Pedidos do Dia */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="sm" className="mt-4 gap-2">
                    <History className="w-4 h-4" />
                    Meus pedidos de hoje
                    {todayOrders.length > 0 && (
                      <span className="bg-primary text-primary-foreground text-xs px-1.5 py-0.5 rounded-full">
                        {todayOrders.length}
                      </span>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="bottom" className="h-[70vh] rounded-t-3xl">
                  <SheetHeader>
                    <SheetTitle>Pedidos de hoje</SheetTitle>
                  </SheetHeader>
                  <div className="mt-4 space-y-4 overflow-y-auto max-h-[calc(70vh-80px)]">
                    {todayOrders.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <History className="w-12 h-12 mx-auto mb-3 opacity-50" />
                        <p>Você ainda não fez pedidos hoje.</p>
                      </div>
                    ) : (
                      todayOrders.map((order) => (
                        <div
                          key={order.id}
                          className="bg-card border border-border rounded-xl p-4 space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">
                              Pedido #{order.id}
                            </span>
                            <StatusBadge status={order.status} />
                          </div>
                          <div className="space-y-1">
                            {order.items.map((item) => (
                              <div
                                key={item.productId}
                                className="flex justify-between text-sm"
                              >
                                <span>
                                  {item.quantity}x {item.productName}
                                </span>
                                <span className="text-muted-foreground">
                                  {formatPrice(item.subtotal)}
                                </span>
                              </div>
                            ))}
                          </div>
                          <div className="flex justify-between pt-2 border-t border-border font-semibold">
                            <span>Total</span>
                            <span className="text-primary">{formatPrice(order.total)}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      {/* Products */}
      <main className="px-4 pb-32 max-w-2xl mx-auto">
        <h2 className="text-lg font-semibold text-foreground mb-4">
          Produtos disponíveis
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </main>

      {/* Fixed Cart Summary */}
      {itemCount > 0 && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-background border-t border-border shadow-lg">
          <div className="max-w-2xl mx-auto">
            <Button
              variant="premium"
              size="xl"
              className="w-full"
              onClick={() => navigate('/checkout')}
            >
              <ShoppingBag className="w-5 h-5 mr-2" />
              Finalizar pedido ({itemCount} {itemCount === 1 ? 'item' : 'itens'}) • {formatPrice(total)}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default StorePage;
