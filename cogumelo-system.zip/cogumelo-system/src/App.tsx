import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { CartProvider } from "@/contexts/CartContext";
import { AuthProvider } from "@/contexts/AuthContext";

// Pages
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import LoginPage from "./pages/LoginPage";
import StorePage from "./pages/loja/StorePage";
import CheckoutPage from "./pages/CheckoutPage";
import OrderConfirmedPage from "./pages/OrderConfirmedPage";

// Producer Pages
import ProducerDashboard from "./pages/app/produtor/Dashboard";
import ProducerProducts from "./pages/app/produtor/Products";
import ProducerOrders from "./pages/app/produtor/Orders";
import ProducerSettings from "./pages/app/produtor/Settings";

// Admin Pages
import AdminDashboard from "./pages/app/admin/Dashboard";
import AdminProducers from "./pages/app/admin/Producers";
import AdminSettings from "./pages/app/admin/Settings";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <CartProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/loja/:slug" element={<StorePage />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/pedido-confirmado" element={<OrderConfirmedPage />} />

              {/* Producer Routes */}
              <Route path="/app/produtor/dashboard" element={<ProducerDashboard />} />
              <Route path="/app/produtor/produtos" element={<ProducerProducts />} />
              <Route path="/app/produtor/pedidos" element={<ProducerOrders />} />
              <Route path="/app/produtor/configuracoes" element={<ProducerSettings />} />

              {/* Admin Routes */}
              <Route path="/app/admin/dashboard" element={<AdminDashboard />} />
              <Route path="/app/admin/produtores" element={<AdminProducers />} />
              <Route path="/app/admin/configuracoes" element={<AdminSettings />} />

              {/* Catch-all */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </CartProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
