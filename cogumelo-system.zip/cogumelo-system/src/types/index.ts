// Core Types for Multi-tenant SaaS

export interface Producer {
  id: string;
  slug: string;
  name: string;
  email: string;
  phone?: string;
  location: string;
  logo?: string;
  coverImage?: string;
  isActive: boolean;
  createdAt: Date;
  // Subscription info
  subscriptionStatus: SubscriptionStatus;
  subscriptionPlan?: string;
  subscriptionStartDate?: Date;
  subscriptionEndDate?: Date;
  lastPaymentDate?: Date;
}

export type SubscriptionStatus = 'ativo' | 'pendente' | 'atrasado' | 'cancelado';

export interface Product {
  id: string;
  producerId: string;
  name: string;
  description: string;
  price: number;
  unit: 'kg' | 'bandeja' | 'pacote' | 'unidade';
  image?: string;
  isActive: boolean;
  stock?: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  producerId: string;
  producerName: string;
  items: OrderItem[];
  total: number;
  status: OrderStatus;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  paymentMethod: PaymentMethod;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  unit: string;
  subtotal: number;
}

export type OrderStatus = 'novo' | 'confirmado' | 'preparo' | 'a_caminho' | 'finalizado' | 'cancelado';

export type PaymentMethod = 'pix' | 'dinheiro' | 'cartao';

export type UserRole = 'admin' | 'producer' | 'customer';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  producerId?: string;
}

export interface DashboardStats {
  ordersToday: number;
  pendingOrders: number;
  totalRevenue: number;
  totalProducts?: number;
  totalProducers?: number;
}
